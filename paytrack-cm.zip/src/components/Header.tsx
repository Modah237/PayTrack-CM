import React from 'react';
import { Search, Bell, User } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

export function Header() {
  return (
    <header className="h-16 border-b border-slate-200 bg-white flex items-center justify-between px-8 sticky top-0 z-10">
      <div className="relative w-96">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
        <Input 
          placeholder="Rechercher une facture, un client..." 
          className="pl-10 bg-slate-50 border-slate-200 focus:bg-white transition-colors"
        />
      </div>
      
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" className="relative text-slate-500">
          <Bell className="w-5 h-5" />
          <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
        </Button>
        <div className="h-8 w-[1px] bg-slate-200 mx-2"></div>
        <div className="flex items-center gap-2">
          <div className="text-right hidden sm:block">
            <p className="text-sm font-medium text-slate-900 leading-none">Jean Dupont</p>
            <p className="text-xs text-slate-500 mt-1">Administrateur</p>
          </div>
          <Button variant="ghost" size="icon" className="rounded-full bg-slate-100">
            <User className="w-5 h-5 text-slate-600" />
          </Button>
        </div>
      </div>
    </header>
  );
}
