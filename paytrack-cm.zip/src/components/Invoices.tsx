import React, { useState } from 'react';
import { 
  Plus, 
  Filter, 
  Search, 
  MoreVertical, 
  Send, 
  CheckCircle, 
  Clock, 
  AlertCircle,
  FileText,
  Download,
  ExternalLink
} from 'lucide-react';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger,
  DropdownMenuSeparator
} from '@/components/ui/dropdown-menu';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { mockInvoices } from '@/mockData';
import { InvoiceStatus } from '@/types';
import { cn } from '@/lib/utils';

export function Invoices() {
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredInvoices = mockInvoices.filter(inv => {
    const matchesStatus = statusFilter === 'all' || inv.status === statusFilter;
    const matchesSearch = inv.clientName.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         inv.invoiceNumber.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const getStatusBadge = (status: InvoiceStatus) => {
    switch (status) {
      case 'paid':
        return <Badge className="bg-emerald-100 text-emerald-700 border-none shadow-none hover:bg-emerald-100 gap-1.5"><CheckCircle className="w-3 h-3" /> Payée</Badge>;
      case 'overdue':
        return <Badge className="bg-red-100 text-red-700 border-none shadow-none hover:bg-red-100 gap-1.5"><AlertCircle className="w-3 h-3" /> En retard</Badge>;
      case 'pending':
        return <Badge className="bg-blue-100 text-blue-700 border-none shadow-none hover:bg-blue-100 gap-1.5"><Clock className="w-3 h-3" /> En attente</Badge>;
      case 'partially_paid':
        return <Badge className="bg-orange-100 text-orange-700 border-none shadow-none hover:bg-orange-100 gap-1.5"><Clock className="w-3 h-3" /> Partielle</Badge>;
    }
  };

  return (
    <div className="p-8 space-y-8 max-w-[1600px] mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-slate-900">Factures</h2>
          <p className="text-slate-500 mt-1">Gérez vos factures et suivez les paiements en temps réel.</p>
        </div>
        <Button className="bg-blue-600 hover:bg-blue-700 gap-2">
          <Plus className="w-4 h-4" />
          Nouvelle Facture
        </Button>
      </div>

      <Card className="border-none shadow-sm bg-white overflow-hidden">
        <CardHeader className="border-b border-slate-100 bg-slate-50/30">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-4 flex-1 max-w-2xl">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input 
                  placeholder="Rechercher par client ou numéro..." 
                  className="pl-10 bg-white border-slate-200"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[180px] bg-white border-slate-200">
                  <SelectValue placeholder="Tous les statuts" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tous les statuts</SelectItem>
                  <SelectItem value="paid">Payées</SelectItem>
                  <SelectItem value="pending">En attente</SelectItem>
                  <SelectItem value="overdue">En retard</SelectItem>
                  <SelectItem value="partially_paid">Partielles</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" className="gap-2">
                <Filter className="w-4 h-4" />
                Plus de filtres
              </Button>
              <Button variant="outline" size="sm" className="gap-2">
                <Download className="w-4 h-4" />
                Exporter CSV
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader className="bg-slate-50/50">
              <TableRow>
                <TableHead className="pl-6 w-[150px]">N° Facture</TableHead>
                <TableHead>Client</TableHead>
                <TableHead>Date d'émission</TableHead>
                <TableHead>Échéance</TableHead>
                <TableHead>Montant</TableHead>
                <TableHead>Statut</TableHead>
                <TableHead className="text-right pr-6">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredInvoices.map((invoice) => (
                <TableRow key={invoice.id} className="hover:bg-slate-50/50 transition-colors group">
                  <TableCell className="font-medium pl-6">
                    <div className="flex items-center gap-2">
                      <FileText className="w-4 h-4 text-slate-400 group-hover:text-blue-600 transition-colors" />
                      {invoice.invoiceNumber}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="font-medium text-slate-900">{invoice.clientName}</div>
                  </TableCell>
                  <TableCell className="text-slate-500">
                    {new Date(invoice.createdAt).toLocaleDateString('fr-FR')}
                  </TableCell>
                  <TableCell className={cn(
                    "text-slate-500",
                    invoice.status === 'overdue' && "text-red-600 font-medium"
                  )}>
                    {new Date(invoice.dueDate).toLocaleDateString('fr-FR')}
                  </TableCell>
                  <TableCell>
                    <div className="font-bold text-slate-900">{invoice.amount.toLocaleString()} XAF</div>
                    {invoice.paidAmount > 0 && (
                      <div className="text-[10px] text-emerald-600 uppercase tracking-wider font-medium">
                        Payé: {invoice.paidAmount.toLocaleString()} XAF
                      </div>
                    )}
                  </TableCell>
                  <TableCell>
                    {getStatusBadge(invoice.status)}
                  </TableCell>
                  <TableCell className="text-right pr-6">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-slate-400 hover:text-slate-900">
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-48">
                        <DropdownMenuItem className="gap-2">
                          <ExternalLink className="w-4 h-4" /> Voir les détails
                        </DropdownMenuItem>
                        <DropdownMenuItem className="gap-2">
                          <Download className="w-4 h-4" /> Télécharger PDF
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem className="gap-2 text-blue-600 focus:text-blue-600">
                          <Send className="w-4 h-4" /> Envoyer relance
                        </DropdownMenuItem>
                        <DropdownMenuItem className="gap-2 text-emerald-600 focus:text-emerald-600">
                          <CheckCircle className="w-4 h-4" /> Marquer comme payée
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
          {filteredInvoices.length === 0 && (
            <div className="p-12 text-center">
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-slate-100 text-slate-400 mb-4">
                <Search className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-medium text-slate-900">Aucune facture trouvée</h3>
              <p className="text-slate-500 max-w-xs mx-auto mt-1">
                Essayez de modifier vos filtres ou de créer une nouvelle facture.
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
