import React from 'react';
import { 
  Bell, 
  MessageSquare, 
  Mail, 
  Smartphone,
  Clock,
  CheckCircle2,
  AlertCircle,
  Play
} from 'lucide-react';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription 
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';

const mockReminders = [
  { id: 1, client: 'Lycée Privé Excellence', invoice: 'FAC-2026-001', channel: 'WhatsApp', status: 'sent', date: 'Il y a 2h' },
  { id: 2, client: 'Agro-Distrib SARL', invoice: 'FAC-2026-005', channel: 'SMS', status: 'failed', date: 'Il y a 5h' },
  { id: 3, client: 'Cabinet Médical Akwa', invoice: 'FAC-2026-003', channel: 'Email', status: 'pending', date: 'Prévu à 14:00' },
];

export function Reminders() {
  const handleRunRPA = () => {
    toast.success("Moteur de relance activé", {
      description: "3 relances ont été programmées pour aujourd'hui."
    });
  };

  return (
    <div className="p-8 space-y-8 max-w-[1600px] mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-slate-900">Relances Automatiques</h2>
          <p className="text-slate-500 mt-1">Gérez vos scénarios de relance et suivez les envois.</p>
        </div>
        <Button onClick={handleRunRPA} className="bg-orange-600 hover:bg-orange-700 gap-2">
          <Play className="w-4 h-4" />
          Lancer le moteur RPA
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <Card className="border-none shadow-sm bg-white">
            <CardHeader>
              <CardTitle>Relances récentes</CardTitle>
              <CardDescription>Historique des dernières actions de relance.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mockReminders.map((rem) => (
                  <div key={rem.id} className="flex items-center justify-between p-4 rounded-lg border border-slate-100 hover:bg-slate-50 transition-colors">
                    <div className="flex items-center gap-4">
                      <div className={cn(
                        "w-10 h-10 rounded-full flex items-center justify-center",
                        rem.channel === 'WhatsApp' ? "bg-emerald-100 text-emerald-600" :
                        rem.channel === 'SMS' ? "bg-blue-100 text-blue-600" : "bg-slate-100 text-slate-600"
                      )}>
                        {rem.channel === 'WhatsApp' ? <MessageSquare className="w-5 h-5" /> :
                         rem.channel === 'SMS' ? <Smartphone className="w-5 h-5" /> : <Mail className="w-5 h-5" />}
                      </div>
                      <div>
                        <p className="text-sm font-bold text-slate-900">{rem.client}</p>
                        <p className="text-xs text-slate-500">Facture {rem.invoice} • {rem.channel}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center gap-2 justify-end">
                        <span className="text-xs text-slate-400">{rem.date}</span>
                        {rem.status === 'sent' ? <CheckCircle2 className="w-4 h-4 text-emerald-500" /> :
                         rem.status === 'failed' ? <AlertCircle className="w-4 h-4 text-red-500" /> :
                         <Clock className="w-4 h-4 text-slate-300" />}
                      </div>
                      <Badge variant="outline" className={cn(
                        "mt-1 text-[10px] uppercase tracking-wider",
                        rem.status === 'sent' ? "text-emerald-600 border-emerald-100" :
                        rem.status === 'failed' ? "text-red-600 border-red-100" : "text-slate-400 border-slate-100"
                      )}>
                        {rem.status === 'sent' ? 'Envoyé' : rem.status === 'failed' ? 'Échec' : 'En attente'}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card className="border-none shadow-sm bg-white">
            <CardHeader>
              <CardTitle>Configuration RPA</CardTitle>
              <CardDescription>Scénarios de relance actifs.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 rounded-md bg-slate-50 border border-slate-100">
                  <div className="flex items-center gap-3">
                    <Badge className="bg-blue-600">J-3</Badge>
                    <span className="text-sm font-medium">Rappel doux (SMS)</span>
                  </div>
                  <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
                </div>
                <div className="flex items-center justify-between p-3 rounded-md bg-slate-50 border border-slate-100">
                  <div className="flex items-center gap-3">
                    <Badge className="bg-emerald-600">J+0</Badge>
                    <span className="text-sm font-medium">Échéance (WhatsApp)</span>
                  </div>
                  <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
                </div>
                <div className="flex items-center justify-between p-3 rounded-md bg-slate-50 border border-slate-100">
                  <div className="flex items-center gap-3">
                    <Badge className="bg-orange-600">J+7</Badge>
                    <span className="text-sm font-medium">1ère Relance (WhatsApp)</span>
                  </div>
                  <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
                </div>
                <div className="flex items-center justify-between p-3 rounded-md bg-slate-50 border border-slate-100">
                  <div className="flex items-center gap-3">
                    <Badge className="bg-red-600">J+30</Badge>
                    <span className="text-sm font-medium">Mise en demeure (Email)</span>
                  </div>
                  <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
                </div>
              </div>
              <Button variant="outline" className="w-full">Modifier les scénarios</Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

import { cn } from '@/lib/utils';
