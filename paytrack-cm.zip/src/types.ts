
export type InvoiceStatus = 'paid' | 'pending' | 'overdue' | 'partially_paid';

export interface Invoice {
  id: string;
  invoiceNumber: string;
  clientName: string;
  clientId: string;
  amount: number;
  paidAmount: number;
  dueDate: string;
  createdAt: string;
  status: InvoiceStatus;
}

export interface Client {
  id: string;
  name: string;
  email: string;
  phone: string;
  totalDue: number;
  creditScore: number; // 0-100
  lastPaymentDate?: string;
}

export interface Payment {
  id: string;
  invoiceId: string;
  amount: number;
  method: 'momo_mtn' | 'momo_orange' | 'card' | 'cash';
  date: string;
  transactionRef: string;
}

export interface DashboardStats {
  totalReceivable: number;
  recoveredThisMonth: number;
  overdueAmount: number;
  recoveryRate: number;
}
