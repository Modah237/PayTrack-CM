/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { Dashboard } from './components/Dashboard';
import { Invoices } from './components/Invoices';
import { Clients } from './components/Clients';
import { Reminders } from './components/Reminders';
import { Toaster } from '@/components/ui/sonner';

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'invoices':
        return <Invoices />;
      case 'clients':
        return <Clients />;
      case 'payments':
        return (
          <div className="p-8 flex flex-col items-center justify-center h-[calc(100vh-120px)] text-center">
            <div className="w-16 h-16 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mb-4">
              <span className="text-2xl font-bold">P</span>
            </div>
            <h2 className="text-2xl font-bold text-slate-900">Historique des Paiements</h2>
            <p className="text-slate-500 mt-2 max-w-md">
              Consultez tous les paiements reçus via MTN MoMo, Orange Money et Carte Bancaire.
            </p>
            <div className="mt-8 p-12 border-2 border-dashed border-slate-200 rounded-xl bg-slate-50">
              <p className="text-slate-400 italic">Module en cours de chargement...</p>
            </div>
          </div>
        );
      case 'reminders':
        return <Reminders />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="flex h-screen bg-slate-50 font-sans antialiased overflow-hidden">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        <main className="flex-1 overflow-y-auto bg-slate-50/50">
          {renderContent()}
        </main>
      </div>
      
      <Toaster position="top-right" />
    </div>
  );
}
