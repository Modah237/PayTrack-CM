import { Invoice, Client, DashboardStats } from './types';

export const mockClients: Client[] = [
  { id: '1', name: 'Lycée Privé Excellence', email: 'contact@excellence.cm', phone: '+237 670000001', totalDue: 2500000, creditScore: 65 },
  { id: '2', name: 'ETS NANA & Fils', email: 'nana@gmail.com', phone: '+237 690000002', totalDue: 1200000, creditScore: 82 },
  { id: '3', name: 'Cabinet Médical Akwa', email: 'info@medicalakwa.cm', phone: '+237 670000003', totalDue: 450000, creditScore: 45 },
  { id: '4', name: 'Boutique Fatou', email: 'fatou@shop.cm', phone: '+237 690000004', totalDue: 300000, creditScore: 90 },
  { id: '5', name: 'Agro-Distrib SARL', email: 'sales@agrodistrib.cm', phone: '+237 670000005', totalDue: 5600000, creditScore: 70 },
];

export const mockInvoices: Invoice[] = [
  { id: 'inv_1', invoiceNumber: 'FAC-2026-001', clientName: 'Lycée Privé Excellence', clientId: '1', amount: 750000, paidAmount: 0, dueDate: '2026-04-10', createdAt: '2026-03-10', status: 'overdue' },
  { id: 'inv_2', invoiceNumber: 'FAC-2026-002', clientName: 'ETS NANA & Fils', clientId: '2', amount: 450000, paidAmount: 450000, dueDate: '2026-04-15', createdAt: '2026-03-15', status: 'paid' },
  { id: 'inv_3', invoiceNumber: 'FAC-2026-003', clientName: 'Cabinet Médical Akwa', clientId: '3', amount: 150000, paidAmount: 50000, dueDate: '2026-04-20', createdAt: '2026-03-20', status: 'partially_paid' },
  { id: 'inv_4', invoiceNumber: 'FAC-2026-004', clientName: 'Boutique Fatou', clientId: '4', amount: 300000, paidAmount: 0, dueDate: '2026-05-01', createdAt: '2026-04-01', status: 'pending' },
  { id: 'inv_5', invoiceNumber: 'FAC-2026-005', clientName: 'Agro-Distrib SARL', clientId: '5', amount: 1200000, paidAmount: 0, dueDate: '2026-04-05', createdAt: '2026-03-05', status: 'overdue' },
];

export const mockStats: DashboardStats = {
  totalReceivable: 10050000,
  recoveredThisMonth: 3450000,
  overdueAmount: 4200000,
  recoveryRate: 68,
};
